# What is this?

This is the Linux kernel IIO drivers for the sensors used in the Coral
Environment Sensor board.

Note: These files are mostly identical to the drivers in mainline linux (iio/).
There are trivial changes for ease of use for DKMS.

